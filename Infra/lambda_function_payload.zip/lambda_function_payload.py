import boto3

def lambda_handler(event, context):
    ssm = boto3.client('ssm')
    response = ssm.get_parameter(
        Name='/myapp/db-password',
        WithDecryption=True
    )
    print("Parameter Value:", response['Parameter']['Value'])
